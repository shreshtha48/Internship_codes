import pyarxaas 
from pyarxaas import Dataset,ARXaaS,privacy_models
from abc import ABC, abstractclassmethod
import pandas as pd
import numpy as np
import warnings 
import collections
class anonymization(ABC):
    def __init__(self,data=pd.DataFrame):
        #this connects to the local arx instance
        self.__arxaas=ARXaaS("http://localhost.8080/")
        #this takes in the data 
        self.data=data
        try:
            #converting the dataset from pandas 
            self.dataset=Dataset.from_pandas(data)
        except Exception as error:
            print(f"could not convert your dataframe to dataset because of error {error}")
        # Example usage:
        #deal with the distribution and all of the stuff before the data has been processed
    @abstractclassmethod
    def reidentification_risk():
        pass
    #this is an abstract method because the reidentification risk before and after the anonymization will not be the same
    @abstractclassmethod
    def set_attributes(self):
        #this will set the attribute to the columns depending on the type of the data
        pass