import pandas as pd
import matplotlib.pyplot as plt
from tkinter import *
from tkinter import filedialog
from tkinter import messagebox

class DataFrameGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Dataframe GUI")
        
        # create widgets
        self.upload_button = Button(self.master, text="Upload Dataframe", command=self.upload_dataframe)
        self.display_button = Button(self.master, text="Display Dataframe", command=self.display_dataframe)
        self.plot_button = Button(self.master, text="Generate Plot", command=self.generate_plot)
        self.data_label = Label(self.master, text="Dataframe will be displayed here.")
        self.status_label = Label(self.master, text="")
        
        # position widgets
        self.upload_button.grid(row=0, column=0, padx=10, pady=10)
        self.display_button.grid(row=0, column=1, padx=10, pady=10)
        self.plot_button.grid(row=0, column=2, padx=10, pady=10)
        self.data_label.grid(row=1, column=0, columnspan=3, padx=10, pady=10)
        self.status_label.grid(row=2, column=0, columnspan=3)
        
        self.dataframe = None
        
    def upload_dataframe(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if file_path:
            try:
                self.dataframe = pd.read_csv(file_path)
                self.status_label.config(text="Dataframe uploaded successfully.")
            except Exception as e:
                self.status_label.config(text=f"Error uploading dataframe: {str(e)}")
        else:
            self.status_label.config(text="No file selected.")
    
    def display_dataframe(self):
        if self.dataframe is None:
            messagebox.showwarning("No Dataframe", "Please upload a dataframe first.")
        elif self.dataframe.empty:
            messagebox.showwarning("Empty Dataframe", "The uploaded dataframe is empty.")
        else:
            self.data_label.config(text=self.dataframe.head(50))
    
    def generate_plot(self):
        if self.dataframe is None:
            messagebox.showwarning("No Dataframe", "Please upload a dataframe first.")
        elif self.dataframe.empty:
            messagebox.showwarning("Empty Dataframe", "The uploaded dataframe is empty.")
        else:
            self.dataframe.plot()
            plt.show()

# create GUI
root = Tk()
gui = DataFrameGUI(root)
root.mainloop()
