import pandas as pd
#this function works just fine now, we have created a function to read the hierarchies in the structure needed for this god-awful code
def read_hierarchy_from_dataframe(df):
    """
    Reads a hierarchy from a Pandas DataFrame with columns representing the different levels.

    :param df: Pandas DataFrame containing the hierarchy
    :return: List of dictionaries representing the hierarchy
    """
    headers = list(df.columns)

    gen_hier = []
    for header in headers[1:]:
        gen_hier.append({})

    for row in df.itertuples(index=False):
        for i, value in enumerate(row[1:]):
            if i == 0:
                parent = value
            else:
                try:
                    gen_hier[i-1][value].append(parent)
                except KeyError:
                    gen_hier[i-1].update({value: [parent]})

    return gen_hier

hierarchy=pd.read_csv("/home/shreshtha/Downloads/agehier.csv")
my_hierarchy = read_hierarchy_from_dataframe(hierarchy)
print(my_hierarchy)