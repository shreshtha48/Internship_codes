import snowflake.connector
import pandas as pd
from pyarxaas import ARXaaS
from pyarxaas.privacy_models import KAnonymity
from pyarxaas import AttributeType
from pyarxaas import Dataset
import time

arxToolurl="http://localhost:8080"
#somewhow need to set the regex to create variable names from the file path and set them while iterating thru for loop
Name="/hierarchies/namehier.csv"
Age="/hierarchies/agehier.csv"
Email= "/hierarchies/emailhier.csv"
Gender="hierarchies/gender.csv"
zipcode="/hierarchies/zipcode.csv"
Amount_spent="/hierarchies/amounthier.csv"
""" db_result="db_result.csv" """
def hierarchy(dataset):
    try:
        dataset.set_attribute_type(AttributeType.QUASIIDENTIFYING, 'Gender','Age','Amount_spent','Email','Zipcode','Name')
        gender_hierarchy = pd.read_csv(Gender)
        dataset.set_hierarchy('Gender', gender_hierarchy)
        name_hierarchy=pd.read_csv(Name)
        dataset.set_hierarchy('Name',name_hierarchy)
        age_hierarchy=pd.read_csv(Age)
        dataset.set_hierarchy('Age',age_hierarchy)
        email_hierarchy=pd.read_csv(Email)
        dataset.set_hierarchy("Email",email_hierarchy)
        zipcode_hierarchy=pd.read_csv(zipcode)
        dataset.set_hierarchy("zipcode",zipcode_hierarchy)
        amount_hierarchy=pd.read_csv(Amount_spent)
        dataset.set_hierarchy("Amount_spent",amount_hierarchy)
        def anonymization(dataset):
    try:
        arxaas = ARXaaS(arxToolurl)
        kanon = KAnonymity(4)
        # specify the dataset as the first parameter, and privacy model list as the second paramter
        anonymize_result = arxaas.anonymize(dataset, [kanon])
        # get the new dataset
        anonymized_dataset = anonymize_result.dataset
        #print("Anonymized dataset",anonymized_dataset)
        anon_dataframe = anonymized_dataset.to_dataframe()
        print("Anonymized dataframe: \n",anon_dataframe)
        pd.DataFrame(anon_dataframe).to_csv('annoymize_output.csv',index=False)
        # get the risk profile for the new dataset
        anon_risk_profile = anonymize_result.risk_profile
        # get risk metrics as a dictionary
        re_indentifiation_risk = anon_risk_profile.re_identification_risk
        distribution_of_risk = anon_risk_profile.distribution_of_risk
        # get risk metrivs as pandas.DataFrame
        re_i_risk_df = anon_risk_profile.distribution_of_risk_dataframe()
        dist_risk_df = anon_risk_profile.distribution_of_risk_dataframe()
        # get the anonymiztion metrics
        anon_metrics = anonymize_result.anonymization_metrics
        return True
    except Exception as e:
        pass
        print (e)

""" data=pd.read_csv("./customer_data.csv")
dataset=Dataset.from_pandas(data)
anonymized=anonymization(dataset)
print(anonymized.generaliz """
def anonymization(dataset):
    try:
        arxaas = ARXaaS(arxToolurl)
        kanon = KAnonymity(4)
        # specify the dataset as the first parameter, and privacy model list as the second paramter
        anonymize_result = arxaas.anonymize(dataset, [kanon])
        # get the new dataset
        anonymized_dataset = anonymize_result.dataset
        #print("Anonymized dataset",anonymized_dataset)
        anon_dataframe = anonymized_dataset.to_dataframe()
        print("Anonymized dataframe: \n",anon_dataframe)
        pd.DataFrame(anon_dataframe).to_csv('annoymize_output.csv',index=False)
        # get the risk profile for the new dataset
        anon_risk_profile = anonymize_result.risk_profile
        # get risk metrics as a dictionary
        re_indentifiation_risk = anon_risk_profile.re_identification_risk
        distribution_of_risk = anon_risk_profile.distribution_of_risk
        # get risk metrivs as pandas.DataFrame
        re_i_risk_df = anon_risk_profile.distribution_of_risk_dataframe()
        dist_risk_df = anon_risk_profile.distribution_of_risk_dataframe()
        # get the anonymiztion metrics
        anon_metrics = anonymize_result.anonymization_metrics
        return True
    except Exception as e:
        pass
        print (e)
data=pd.read_csv("./customer_data.csv")
dataset=Dataset.from_pandas(data)
anonymized=hierarchy(dataset)
final=anonymization(anonymized)
