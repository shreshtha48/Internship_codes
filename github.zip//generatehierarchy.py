import pyarxaas 
from pyarxaas import Dataset,ARXaaS,privacy_models
from abc import ABC, abstractclassmethod
import pandas as pd
import numpy as np
import warnings 
import collections
from anonymization import anonymization
class generate_hierarchy(anonymization):
    def __init__(self):
        self.data=anonymization.data
        super.__init__(data=self.data)
        anonymization.__data_cleanup()
    def interval_based(self,column):
        self.column=self.dataset[column].unique()
    def reduction_based(self,column):
        pass
    def date_based(self,column):
        pass
    def order_based(self,column):
        pass
    def reidentification_risk(self):
        #generates the reidentification risk for the dataset
       try:
        self.reidentification_risk=ARXaaS.risk_profile(dataset=self.dataset)
        print(self.reidentification_risk.re_identification_risk)
        print(self.reidentification_risk.attacker_sucess_rate)
        print(self.reidentification_risk.quasi_identifiers)
        print(self.reidentification_risk.population_model)
        print(self.reidentification_risk.distribution_of_risk)
       except Exception as error:
        print(f"could not generate the reidentification risk due to the error {error}")
