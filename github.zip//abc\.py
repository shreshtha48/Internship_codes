import tkinter as tk

class LoginPage:
    def __init__(self, master):
        self.master = master
        master.title("Login")

        # create username label and entry
        self.username_label = tk.Label(master, text="Username:")
        self.username_label.pack()
        self.username_entry = tk.Entry(master)
        self.username_entry.pack()

        # create password label and entry
        self.password_label = tk.Label(master, text="Password:")
        self.password_label.pack()
        self.password_entry = tk.Entry(master, show="*")
        self.password_entry.pack()

        # create login button
        self.login_button = tk.Button(master, text="Login", command=self.login)
        self.login_button.pack()

        # create label for error messages
        self.error_label = tk.Label(master, text="", fg="red")
        self.error_label.pack()

    def login(self):
        # check if username and password are correct
        if self.username_entry.get() == "username" and self.password_entry.get() == "password":
            # clear error message
            self.error_label.config(text="")

            # open main window or do other actions after login
            self.open_main_window()
        else:
            # display error message
            self.error_label.config(text="Invalid username or password")

    def open_main_window(self):
        # create main window
        main_window = tk.Toplevel(self.master)
        main_window.title("Main Window")

        # add widgets to main window
        label = tk.Label(main_window, text="Welcome!")
        label.pack()

# create root window and login page
root = tk.Tk()
login_page = LoginPage(root)

# run application
root.mainloop()
