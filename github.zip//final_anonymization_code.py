import pyarxaas 
from pyarxaas import Dataset,ARXaaS,privacy_models
from abc import ABC, abstractclassmethod
import pandas as pd
import numpy as np
import warnings 
import collections
from anonymization import anonymization
class data_cleanup(anonymization):
    def __init__(self,data):
        super().__init__(data=data)
    def __data_cleanup(self):
        #this should capitalize all the column names or at the very least get them in the proper format
        def capitalize_columns(self):
            self.data.columns = map(str.upper, self.data.columns)
            return self.data
        #gets rid of the missing values in the dataset
    def remove_missing_rows(self):
    # Calculate the percentage of missing values in each column
          self.missing_percentages = self.data.isna().sum() / len(self.data) * 100
    
    # Check if any column has more than 50% missing values
          if any(self.datamissing_percentages > 50):
             warnings.warn("The DataFrame has more than 50% missing values!")
    # Remove rows with missing values
          self.data.dropna(inplace=True)
          return self.data
        #convert all the numerical columns to int if they are float
    def convert_float_to_int(self):
        #this checks if the columns of the dataframe are float or not, if they are then they are converted from int to float
       for col in self.data.columns:
        if np.issubdtype(self.data[col].dtype, np.floating):
            self.data[col] = self.data[col].astype(int)
       return self.data
    #a function to identify if they are categorical variables in the dataset
    def is_categorical(self):
        #this function identifies if the column in the dataframe is categorical or not
        #however, this method is very not okay because here the categorical columns are technically the ones that have less than 10 unique values
        #these columns dont take in account the numerical columns and will count values such as diabetes and DiaBetEs as unique values hence proper pre processing 
        #will really be needed
        unique_values = set()
        for col in self.data.columns:
           for row in self.data:
                unique_values.add(row[col])
                if len(unique_values) <= 10:
                   return True
                else:
                  return False
    #a function to check the distribution and skweness of the data
    def check_column_distribution(dataframe):
    
        distribution = {}
        num_rows = len(dataframe)
        num_cols = len(dataframe[0])
        for col_idx in range(num_cols):
            column_values = [row[col_idx] for row in dataframe]
            column_distribution = collections.Counter(column_values)
            distribution[col_idx] = column_distribution
            return distribution

