import pyarxaas 
from pyarxaas import Dataset,ARXaaS,privacy_models
from abc import ABC, abstractclassmethod
import pandas as pd
import numpy as np
import warnings 
import collections
from anonymization import anonymization
class set_hierarchy(anonymization):
    #this function sets the hierarchies on the given data
    #this function is the child class of the parent class anonymization which takes the dataframe, cleans it up and then sets the hierarchies
    def __init__(self):
        #the init constructor 
        super().__init__(data=self.data)
        anonymization.__data_cleanup()
        #function to set the hierarchy.
        #this function takes the hierarchy in the form of a csv file 
    def set_hierarchy(self,hierarchy,column):
        self.hierarchy=hierarchy
        if self.hierarchy==pd.DataFrame:
        #making sure that the dataframe is in the right format
          try:
            self.column=self.data[column].to_list()
            self.setting_hierarchy=self.dataset.set_hierarchy(self.column,self.hierarchy)
          except Exception as error:
            print(f"could not set hierarchies in the given coulmn due to {error}")
        else:
            print("Please enter the dataframe in the right format")
        #function to set the reidentficiation risk
    def reidentification_risk(self):
      try:
        self.reidentification_risk=ARXaaS.risk_profile(dataset=self.dataset)
        print(self.reidentification_risk.re_identification_risk)
        print(self.reidentification_risk.attacker_sucess_rate)
        print(self.reidentification_risk.quasi_identifiers)
        print(self.reidentification_risk.population_model)
        print(self.reidentification_risk.distribution_of_risk)
      except Exception as error:
        print(f"could not identify the reidentification risk because of error {error}")
