
""" import pandas as pd
from tkinter import filedialog

class UploadDataFrame:
    def __init__(self, root):
        self.root = root
        self.frame = tk.Frame(self.root)
        self.frame.pack()
        self.upload_button = tk.Button(self.frame, text="Upload", command=self.upload_file)
        self.upload_button.pack(side=tk.LEFT)

    def upload_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.df = pd.read_csv(file_path)
            self.display_preview()

    def display_preview(self):
        self.preview = tk.Toplevel(self.root)
        self.preview.title("Dataframe Preview")
        df_preview = self.df.head()
        for r in range(len(df_preview)):
            for c in range(len(df_preview.columns)):
                tk.Label(self.preview, text=df_preview.iloc[r, c]).grid(row=r, column=c)

if __name__ == "__main__":
    root = tk.Tk()
    app = UploadDataFrame(root)
    root.mainloop()
 """
import pandas as pd
import tkinter as tk
from tkinter import filedialog
from collections import Counter
#import matplotlib.pyplot as plt

""" class UploadDataFrame:
    def __init__(self, root):
        self.root = root
        self.frame = tk.Frame(self.root)
        self.frame.pack()
        self.upload_button = tk.Button(self.frame, text="Upload", command=self.upload_file)
        self.upload_button.pack(side=tk.LEFT)

    def upload_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.df = pd.read_csv(file_path)
            self.display_preview()

    def display_preview(self):
        self.preview = tk.Toplevel(self.root)
        self.preview.title("Dataframe Preview")
        df_preview = self.df.head()
        for r in range(len(df_preview)):
            for c in range(len(df_preview.columns)):
                tk.Label(self.preview, text=df_preview.iloc[r, c]).grid(row=r, column=c)

        self.categorical_labels = {}
        for col in self.df.columns:
            label_var = tk.StringVar()
            tk.Label(self.preview, text=f"{col} is categorical?").grid(row=len(df_preview), column=0)
            tk.Entry(self.preview, textvariable=label_var).grid(row=len(df_preview), column=1)
            self.categorical_labels[col] = label_var

        tk.Button(self.preview, text="Generate Charts", command=self.generate_charts).grid(row=len(df_preview)+1, column=0)

    def generate_charts(self):
        categorical_cols = [col for col, var in self.categorical_labels.items() if var.get().lower() == "yes"]
        for col in categorical_cols:
            col_counts = dict(Counter(self.df[col]))
            plt.bar(col_counts.keys(), col_counts.values())
            plt.title(f"Count of {col}")
            plt.xlabel(col)
            plt.ylabel("Count")
            plt.show()

if __name__ == "__main__":
    root = tk.Tk()
    app = UploadDataFrame(root)
    root.mainloop()
 """
""" class UploadDataFrame:
    def __init__(self, root):
        self.root = root
        self.frame = tk.Frame(self.root)
        self.frame.pack()
        self.upload_button = tk.Button(self.frame, text="Upload", command=self.upload_file)
        self.upload_button.pack(side=tk.LEFT)

    def upload_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.df = pd.read_csv(file_path)
            self.display_preview()

    def display_preview(self):
        self.preview = tk.Toplevel(self.root)
        self.preview.title("Dataframe Preview")
        df_preview = self.df.head()
        for r in range(len(df_preview)):
            for c in range(len(df_preview.columns)):
                label = tk.Label(self.preview, text=df_preview.iloc[r, c])
                label.grid(row=r, column=c)
                label.bind("<Button-1>", lambda event, col=df_preview.columns[c]: self.change_categorical_label(col, label))

        self.categorical_labels = {}
        for col in self.df.columns:
            self.categorical_labels[col] = False

        tk.Button(self.preview, text="Generate Charts", command=self.generate_charts).grid(row=len(df_preview)+1, column=0)

    def change_categorical_label(self, col, label):
        self.categorical_labels[col] = not self.categorical_labels[col]
        label_text = "Yes" if self.categorical_labels[col] else "No"
        label.config(text=label_text)
        label.config(bg='yellow' if self.categorical_labels[col] else 'white')

    def generate_charts(self):
        categorical_cols = [col for col, is_categorical in self.categorical_labels.items() if is_categorical]
        for col in categorical_cols:
            col_counts = dict(Counter(self.df[col]))
            plt.bar(col_counts.keys(), col_counts.values())
            plt.title(f"Count of {col}")
            plt.xlabel(col)
            plt.ylabel("Count")
            plt.show()
if __name__ == "__main__":
    root = tk.Tk()
    app = UploadDataFrame(root)
    root.mainloop()
 """
import pandas as pd
import tkinter as tk
from tkinter import filedialog
from collections import Counter
import matplotlib.pyplot as plt
from tkinter import ttk

class UploadDataFrame:
    def __init__(self, root):
        self.root = root
        self.frame = tk.Frame(self.root)
        self.frame.pack()
        self.upload_button = tk.Button(self.frame, text="Upload", command=self.upload_file)
        self.upload_button.pack(side=tk.LEFT)
        self.df_preview = ttk.Treeview(self.root)

    def upload_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if file_path:
            self.df = pd.read_csv(file_path)
            self.display_preview()

    def display_preview(self):
        # Remove previous preview if any
        self.df_preview.destroy()
        # Create a new Treeview widget to show the dataframe preview
        self.df_preview = ttk.Treeview(self.root)
        self.df_preview.pack()

        # Insert columns
        columns = list(self.df.columns)
        self.df_preview['columns'] = columns
        for col in columns:
            self.df_preview.heading(col, text=col)

        # Insert data
        for i, row in self.df.iterrows():
            values = [str(row[col]) for col in columns]
            self.df_preview.insert("", tk.END, text=str(i), values=values)

        self.categorical_labels = {}
        for col in self.df.columns:
            self.categorical_labels[col] = False

        tk.Button(self.root, text="Generate Charts", command=self.generate_charts).pack()

    def change_categorical_label(self, col):
        self.categorical_labels[col] = not self.categorical_labels[col]
        label_text = "Yes" if self.categorical_labels[col] else "No"
        for widget in self.df_preview.winfo_children():
            if isinstance(widget, ttk.Treeview) and widget["columns"] == (col,):
                widget.item(widget.focus(), values=[label_text])

    def generate_charts(self):
        categorical_cols = [col for col, is_categorical in self.categorical_labels.items() if is_categorical]
        for col in categorical_cols:
            col_counts = dict(Counter(self.df[col]))
            plt.bar(col_counts.keys(), col_counts.values())
            plt.title(f"Count of {col}")
            plt.xlabel(col)
            plt.ylabel("Count")
            plt.show() 

if __name__ == "__main__":
    root = tk.Tk()
    app = UploadDataFrame(root)
    root.mainloop()
