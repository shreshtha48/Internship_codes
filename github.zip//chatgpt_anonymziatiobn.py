""" import pandas as pd
import numpy as np

# Create a sample dataframe
df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie', 'Dave'],
                   'Age': [25, 30, 35, 40],
                   'Gender': ['Female', 'Male', 'Male', 'Male'],
                   'Salary': [50000, 60000, 70000, 80000]})

# Define a function to create a hierarchy for a column
def create_hierarchy(column):
    unique_values = column.unique()
    hierarchy = {}
    for i, value in enumerate(unique_values):
        hierarchy[value] = i
    return hierarchy

# Create hierarchies for 'Age', 'Gender', and 'Salary'
age_hierarchy = create_hierarchy(df['Age'])
gender_hierarchy = create_hierarchy(df['Gender'])
salary_hierarchy = create_hierarchy(df['Salary'])

# Anonymize the dataframe
df['Age'] = df['Age'].apply(lambda x: age_hierarchy[x])
df['Gender'] = df['Gender'].apply(lambda x: gender_hierarchy[x])
df['Salary'] = df['Salary'].apply(lambda x: salary_hierarchy[x])

# Print the anonymized dataframe
print(df)
 """
import pandas as pd
import numpy as np

# Define a function to perform Mondrian anonymization on a column
def mondrian(column, budget):
    """
    column: a pandas Series object representing a column in a dataframe
    budget: the maximum number of distinct values that can be released
    """
    values = column.unique()
    if len(values) <= budget:
        return column
    else:
        values_sorted = np.sort(values)
        num_partitions = int(np.ceil(len(values) / budget))
        partition_size = int(np.ceil(len(values) / num_partitions))
        partition_boundaries = []
        for i in range(num_partitions):
            partition_boundary = values_sorted[(i+1)*partition_size - 1]
            partition_boundaries.append(partition_boundary)
        partition_boundaries = np.unique(partition_boundaries)
        partition_boundaries = np.append(partition_boundaries, np.inf)
        partitions = pd.cut(values, bins=partition_boundaries, labels=False)
        anonymized_column = partitions.astype('object')
        anonymized_column[np.arange(len(partition_boundaries)-1)]= [range(len(partition_boundaries)-1)]
        return anonymized_column[column.index]

# Create a sample dataframe
df = pd.DataFrame({'Name': ['Alice', 'Bob', 'Charlie', 'Dave'],
                   'Age': [25, 30, 35, 40],
                   'Gender': ['Female', 'Male', 'Male', 'Male'],
                   'Salary': [50000, 60000, 70000, 80000]})

# Anonymize the 'Age' and 'Salary' columns using the Mondrian algorithm
df['Age'] = mondrian(df['Age'], 2)
df['Salary'] = mondrian(df['Salary'], 2)

# Print the anonymized dataframe
print(df)
