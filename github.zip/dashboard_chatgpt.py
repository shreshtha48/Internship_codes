import tkinter as tk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np

class Dashboard(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        # create a figure with subplots
        fig = Figure(figsize=(5, 4), dpi=100)
        ax1 = fig.add_subplot(121)
        ax2 = fig.add_subplot(122)

        # generate data for the charts
        x = np.array(['A', 'B', 'C', 'D'])
        y1 = np.array([3, 2, 4, 1])
        y2 = np.array([1, 2, 3, 4])

        # plot a bar chart and a pie chart
        ax1.bar(x, y1)
        ax1.set_title('Bar Chart')
        ax2.pie(y2, labels=x)
        ax2.set_title('Pie Chart')

        # add the figure to a canvas
        canvas = FigureCanvasTkAgg(fig, master=self)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

root = tk.Tk()
dashboard = Dashboard(root)
dashboard.pack(side="top", fill="both", expand=True)
root.mainloop()
