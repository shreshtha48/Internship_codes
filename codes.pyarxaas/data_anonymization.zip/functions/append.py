import pandas as pd
old_dataframe=pd.read_csv("/home/shreshtha/Desktop/Data_anonymization/customer_data.csv")
#appending the data frame
new_data = pd.read_csv('/home/shreshtha/Downloads/customer_data_new.csv')
appened_data=old_dataframe.append(new_data)
appened_data.to_csv("/home/shreshtha/Downloads/appended_data.csv")
