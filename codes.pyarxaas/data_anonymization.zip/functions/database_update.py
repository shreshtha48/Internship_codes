import snowflake.connector
import pandas as pd
from snowflake.sqlalchemy import URL
from sqlalchemy import create_engine

# Set up Snowflake connection
snowflake_user = 'shreshthaeternal'
snowflake_password = 'Eternal@123'
snowflake_account = 'mvwdvom-zi70301',
snowflake_database = 'TEST_DB1'
snowflake_schema = 'MY_SCHEMA'

snowflake_url = URL(
    account=snowflake_account,
    user=snowflake_user,
    password=snowflake_password,
    database=snowflake_database,
    schema=snowflake_schema,
)

engine = create_engine(snowflake_url)

# Name of the Snowflake table to load data into
table_name = 'CUSTOMER_DATA'

# Load data into a Pandas DataFrame
old_dataframe=pd.read_csv("/home/shreshtha/Desktop/Data_anonymization/customer_data.csv")
#appending the data frame
new_data = pd.read_csv('/home/shreshtha/Downloads/customer_data_new.csv')
data=old_dataframe.append(new_data)
print(data)

# Define column types for Snowflake table
column_types = {
    'Name': 'VARCHAR',
    'Gender': 'VARCHAR',
    'Email': 'VARCHAR',
    'Amount_spent': 'INTEGER',
    'zipcode': 'INTEGER',
    'Age': 'INTEGER'
    ,
}

# Convert DataFrame column types
data = data.astype(column_types)

# Connect to Snowflake
conn = snowflake.connector.connect(
    user=snowflake_user,
    password=snowflake_password,
    account=snowflake_account,
    warehouse='your_warehouse',
    database=snowflake_database,
    schema=snowflake_schema
)

# Use Snowflake cursor to execute queries
cursor = conn.cursor()

# Build SQL query for merge operation
merge_query = f"""
MERGE INTO {table_name} t
USING (
    SELECT * FROM VALUES
"""

# Build the list of values to insert or update
value_list = []
for index, row in data.iterrows():
    values = [row['Name'], row['Gender'], row['Email'], row['Amount_spent'], row['zipcode'],row['Age']]
    value_list.append(f"({values[0]}, {values[1]}, {values[2]}, {values[3]}, {values[4]},{values[5]})")

# Add the values to the SQL query
merge_query += ','.join(value_list)

# Complete the SQL query
merge_query += f"""
) AS s (Name, Gender, Email, Amount_spent, zipcode, Age)
ON t.NAME = s.Name
WHEN MATCHED THEN
    UPDATE SET
        GENDER=s.Gender,
        EMAIL = s.Email,
        AMOUNT_SPENT = s.Amount_spent,
        ZIPCODE = s.zipcode,
        AGE=s.Age
WHEN NOT MATCHED THEN
    INSERT (NAME, GENDER, EMAIL, AMOUNT_SPENT, ZIPCODE, AGE)
    VALUES (s.Name, s.Gender, s.Email, s.Amount_spent, s.zipcode, s.Age)
"""

# Execute the SQL query
cursor.execute(merge_query)

# Commit changes to the database
conn.commit()

# Close Snowflake connection
conn.close()
