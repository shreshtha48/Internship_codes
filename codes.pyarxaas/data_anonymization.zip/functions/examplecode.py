#This script aims at performing end to end anonymization using the functions created and uploading the new data
#Step1: In order to fetch the data from snowflake, we need to establish a connection and that is done using the class SnowflakeConnector 
#tis is the code to fetch the data from snowflake
#importing the class to get the data from snowflake
import pandas as pd
from database_connections import SnowflakeConnector
#creating a connection
connector = SnowflakeConnector(
    user='shreshthaeternal',
    password='Eternal@123',
    account='mvwdvom-zi70301',
    warehouse='COMPUTE_WH',
    database='TEST_DB1',
    schema='MY_SCHEMA'
)
#running connect helps us establish a connection to the  database account in snowflake
connector.connect()

# Get dataframe from a CSV table in Snowflake'
#specifying the table name
csv_table_name = 'CUSTOMER_DATA'
data = connector.get_dataframe(csv_table_name)
#looking at the structure of the data
print(data)
#appending the dataframe with newly entered data
new_data=pd.read_csv("/home/shreshtha/Downloads/customer_data_new.2.0.csv") 
updated_data=data.append(new_data)
#uploading the appended dataframe in the original database
connector.upload_dataframe('customer_data',updated_data) 
#anonymizing the said updated data
#loading the class Anonymizer and using the set_hierarchy function to set hierarchy to the data and load the data
from Anonymize_data import Anonymizer
#using the functiom
new_dataframe=Anonymizer.set_hierarchy(data=updated_data,model="Kanonmity")
#just making sure that the new dataframe is correct
print(new_dataframe)
#saving the newly anonymized data to the csv
new_dataframe.to_csv("/home/shreshtha/Downloads/Anonymized_final2.csv")
#UPLOADING THE DATA TO SNOWFLAKE
#now it is the time for us to update the newly anonymized data by using the function upload_dataframe of the class Snowflake Connector
df_new=pd.read_csv("/home/shreshtha/Downloads/Anonymized_final2.csv")
#since the dataframe at various levels can have both numeric and string data, we are saving the data as string
df_new['ZIPCODE']=df_new['ZIPCODE'].astype(str)
df_new['AGE']=df_new['AGE'].astype(str)
df_new['AMOUNT_SPENT']=df_new['AMOUNT_SPENT'].astype(str)
#uploading the said anonymized dataframe to the anonymized table
connector.upload_dataframe('anonymized_data',df_new) 