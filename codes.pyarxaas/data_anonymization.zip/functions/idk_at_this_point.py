import snowflake.connector
import pandas as pd

# Create a connection object
conn = snowflake.connector.connect(
    user='shreshthaeternal',
    password='Eternal@123',
    account='mvwdvom-zi70301',
    warehouse='COMPUTE_WH',
    database='TEST_DB1',
    schema='MY_SCHEMA'
)

# Create a cursor object
cur = conn.cursor()

# Define the table name
table_name = 'ANONYMIZED_DATA'

# Read the data from the table into a Pandas DataFrame
df = pd.read_sql(f"SELECT * FROM {table_name}", conn)
df_new=pd.read_csv("/home/shreshtha/Desktop/Data_anonymization/anonymized_data.csv")
df_new['ZIPCODE']=df_new['ZIPCODE'].astype(str)
df_new['AGE']=df_new['AGE'].astype(str)
df_new['AMOUNT_SPENT']=df_new['AMOUNT_SPENT'].astype(str)
# Merge the data from the DataFrame into the table
merged_df = pd.merge(df, df_new, on=['NAME', 'GENDER', 'EMAIL', 'AMOUNT_SPENT', 'ZIPCODE', 'AGE'], how='outer')
# The 'outer' join keeps all rows from both DataFrames, and fills in missing values with NaN

# Iterate through the merged DataFrame and update or insert rows in the Snowflake table as needed
for index, row in merged_df.iterrows():
    # Check if the row is already in the table
    cur.execute(f"SELECT COUNT(*) FROM {table_name} WHERE NAME = '{row['NAME']}' AND GENDER = '{row['GENDER']}' AND EMAIL = '{row['EMAIL']}' AND AMOUNT_SPENT = {row['AMOUNT_SPENT']} AND ZIPCODE = '{row['ZIPCODE']}' AND AGE = {row['AGE']}")
    result = cur.fetchone()[0]
    if result > 0:
        # If the row is already in the table, update its values
        cur.execute(f"UPDATE {table_name} SET AMOUNT_SPENT = {row['AMOUNT_SPENT']} WHERE NAME = '{row['NAME']}' AND GENDER = '{row['GENDER']}' AND EMAIL = '{row['EMAIL']}' AND ZIPCODE = '{row['ZIPCODE']}' AND AGE = {row['AGE']}")
    else:
        # If the row is not in the table, insert a new row with its values
        cur.execute(f"INSERT INTO {table_name} (NAME, GENDER, EMAIL, AMOUNT_SPENT, ZIPCODE, AGE) VALUES ('{row['NAME']}', '{row['GENDER']}', '{row['EMAIL']}', {row['AMOUNT_SPENT']}, '{row['ZIPCODE']}', {row['AGE']})")

# Commit the changes to the Snowflake table
conn.commit()

# Close the cursor and connection objects
cur.close()
conn.close()
